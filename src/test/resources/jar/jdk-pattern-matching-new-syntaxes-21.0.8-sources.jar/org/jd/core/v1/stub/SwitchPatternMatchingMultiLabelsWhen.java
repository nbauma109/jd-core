package org.jd.core.v1.stub;

public class SwitchPatternMatchingMultiLabelsWhen {
    static void describe(Object o) {
        switch (o) {
            case Integer i when o != null && o.hashCode() > 0 -> System.out.println(1);
            case Long l when o != null && o.hashCode() > 0 -> System.out.println(1);
            default -> System.out.println(0);
        }
    }
}
