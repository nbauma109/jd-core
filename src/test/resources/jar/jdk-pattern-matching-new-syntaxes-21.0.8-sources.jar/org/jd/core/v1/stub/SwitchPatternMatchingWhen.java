package org.jd.core.v1.stub;

public class SwitchPatternMatchingWhen {
    record Point(int x, int y) {}

    static int describe(Object o) {
        return switch (o) {
            case Point p when p.x() > p.y() -> p.x() - p.y();
            case Point p -> p.x() + p.y();
            default -> 0;
        };
    }
}
