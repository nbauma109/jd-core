package org.jd.core.v1.stub;

public class SwitchExpressionLabels {
    int test(int v) {
        return switch (v) {
            case 1, 2 -> 3;
            default -> 4;
        };
    }
}
