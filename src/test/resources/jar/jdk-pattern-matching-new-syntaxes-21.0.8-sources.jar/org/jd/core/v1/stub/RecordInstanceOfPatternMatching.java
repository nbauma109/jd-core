package org.jd.core.v1.stub;

public class RecordInstanceOfPatternMatching {
    record Point(int x, int y) {}

    boolean matches(Object o) {
        return o instanceof Point(int x, int y) && x >= 0 && y >= 0;
    }
}
