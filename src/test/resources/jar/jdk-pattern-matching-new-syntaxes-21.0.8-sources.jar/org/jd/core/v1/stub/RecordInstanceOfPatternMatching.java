package org.jd.core.v1.stub;

public class RecordInstanceOfPatternMatching {
    record Point(int x, int y) {}

    boolean matches(Object o) {
        return o instanceof Point(int x, int y) && x >= 0 && y >= 0;
    }

    boolean matchesNegated(Object o) {
        return o instanceof Point(int x, int y) && !(x >= 0 && y >= 0);
    }

    boolean matchesFromLocals(Object o) {
        if (o instanceof Point(int a, int b)) {
            int x = a, y = b;
            return x >= 0 && y >= 0;
        }
        return false;
    }

    boolean matchesTernaryFalseTrue(Object o) {
        return o instanceof Point(int x, int y) && ((x >= 0 && y >= 0) ? false : true);
    }
}